
<html>
<head>
	<meta charset="utf-8">
	<script src="main.js" type = "text/javascript" ></script>
</head>
<body>
	<input type="text" id="tx" value="Emoji tester"/>
</body>
</html>
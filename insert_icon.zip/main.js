function loadJquery() {
    var checker = document.getElementById("ckJquery");
    if (checker) {} else {
        var a = document.createElement("script");
        a.src = "//c.cokhach.com/jquery-3.3.1.min.js";
        a.type = "text/javascript";
        a.id = "ckJquery";
        var head = document.getElementsByTagName('head')[0];
        head.appendChild(a);
	}
}

function loadEmoji(){
	var check_emoji_bt = document.getElementById("ckEmojiBt");
	if (check_emoji_bt) {} else {
        var a = document.createElement("script");
        a.src = "js/widget_emoji_button.js";
        a.type = "text/javascript";
		a.charset = "utf-8";
        a.id = "ckEmojiBt";
        var head = document.getElementsByTagName('head')[0];
        head.appendChild(a);
	}
}

window.addEventListener("load", loadJquery());
window.addEventListener("load", loadEmoji());
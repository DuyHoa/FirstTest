//iconCode link: https://apps.timwhitlock.info/emoji/tables/unicode

var emojis = [0x1F600, 0x1F602, 0x1F603, 0x1F604, 0x1F605, 0x1F606, 0x1F60A, 0x1F60B, 
			  0x1F60C, 0x1F60D, 0x1F612, 0x1F613, 0x1F614, 0x1F60F, 0x1F34A, 0x1F344,
			  0x1F37F, 0x1F363, 0x1F370, 0x1F355, 0x1F354, 0x1F35F, 0x1F6C0, 0x1F48E, 
			  0x1F5FA, 0x23F0, 0x1F579, 0x1F4DA, 0x1F431, 0x1F42A, 0x1F439, 0x1F424, ];


var array_id_runtime = [];
			  
			  
			  
			  
			  
(function(){
	window.addEventListener("load", function(){
		create_ske_div();
		add_button_insert_icon();
		create_ske_div_in();
		create_close_button()
		create_ske_emoji_in_in();
		QuerryEmoji();
		set_style_();
		turn_on_of_block_emoji();
		insert_emoji();
	});
})();


//var myJson = JSON.stringify(t);
//localStorage.setItem("ObjectJson", myJson);
//var loadObj = localStorage.getItem("ObjectJson");
//var obj = JSON.parse(loadObj);
//var _count = obj.length;

function insert_emoji(){
	$('.blockEmoji').click(function(){
		var ctl = document.getElementById("tx");
		var start_pos_cursor = ctl.selectionStart;
		var end_pos_cursor = ctl.selectionEnd;
		var _id = this.id.slice(10);
		var stringify = String.fromCodePoint(emojis[_id]);
		var str = ctl.value.slice(0, start_pos_cursor) + stringify + ctl.value.slice(end_pos_cursor);
		
		ctl.value = str;
	});
}

function set_style_(){
	var styleElement = document.createElement("style");
	var style_ske_emoji = "#emoji_khung_ngoai{position: absolute; width: 200px; height: 190px;}";
	var style_button_emoji = "#_id_button_emoji{margin-bottom: 5px; cursor: pointer; width: 25px; height: 25px; border: 1px solid #666; }";
	var style_button_emojiHover = "#_id_button_emoji:hover {box-shadow: 0px 0px 3px 1px rgba(8, 8, 8, 0.17);}";
	var style_ske_emoji_trong = "#emoji_khung_trong{background-color: rgba(210, 178, 178, 0.47); position:relative; box-shadow: 0px 0px 1px 1px rgba(8, 8, 8, 0.16); border: 1px solid #666; height: 132px; padding: 5px; padding-top: 20px;}";
	var style_ske_emoji_tronger = "#emoji_khung_trong-er{background-color: white; opacity: 1; position: relative; border: 1px solid #666; height: 124px; padding: 3px; overflow-y: scroll;}";
	var style_blockEmoji = ".blockEmoji{position: relative; cursor: pointer; display: inline-block; width: 23px; height: 23px; padding: 3px; margin: 1px; border: 1px solid #fff; text-align: center;}";
	var style_blockEmojiHover = ".blockEmoji:hover {border: 1px solid #333;}"
	var style_scrollBar = "#emoji_khung_trong-er::-webkit-scrollbar {width: 8px;}	#emoji_khung_trong-er::-webkit-scrollbar-track {box-shadow: inset 0 0 5px grey; border-radius: 10px;}	#emoji_khung_trong-er::-webkit-scrollbar-thumb{background: #666; border-radius: 10px;}	#emoji_khung_trong-er::-webkit-scrollbar-thumb:hover{background: #333;}";
	var style_btCloseHover = "#close_bt:hover{transition: 0.8s ; background-color: red; color: white;}"
	var style_btClose = "#close_bt{cursor: pointer; position: absolute; float: left; top: 0px; right: 5px; text-align: center; height: 16px; width: 20px; font-family: roboto; font-size: 12px;}";
	
	var stringify = style_ske_emoji + style_button_emoji + style_button_emojiHover + style_ske_emoji_trong + style_ske_emoji_tronger + style_blockEmoji + style_blockEmojiHover + style_scrollBar + style_btClose + style_btCloseHover;
	styleElement.appendChild(document.createTextNode(stringify));
	document.getElementsByTagName("head")[0].appendChild(styleElement);
}

function create_ske_div(){
	var ske_out = document.createElement("div");
	ske_out.className = "Emoji_button";
	ske_out.id = "emoji_khung_ngoai";
	var a_out = document.getElementsByTagName("body");
	a_out[0].append(ske_out);
}

function create_ske_div_in(){
	var ske_in = document.createElement("div");
	ske_in.className = "Emoji_button";
	ske_in.id = "emoji_khung_trong";
	ske_in.style.display = "none";
	var a = document.getElementById("emoji_khung_ngoai");
	a.append(ske_in);
}

function create_close_button(){
	var _close_bt = document.createElement("div");
	_close_bt.id = "close_bt";
	_close_bt.innerHTML = "x";
	var a = document.getElementById("emoji_khung_trong");
	a.appendChild(_close_bt);
}

function create_ske_emoji_in_in(){
	var ske_in_in = document.createElement("div");
	ske_in_in.className = "Emoji_button";
	ske_in_in.id = "emoji_khung_trong-er";
	var a = document.getElementById("emoji_khung_trong");
	a.append(ske_in_in);
}

function add_button_insert_icon(){
	var button_icon = document.createElement("div");
	button_icon.id = "_id_button_emoji";
	//button_icon.innerHTML = String.fromCodePoint(0x263A);
	var a = document.getElementById("emoji_khung_ngoai");
	a.append(button_icon);	
}

function QuerryEmoji(){
	var toAdd = document.createDocumentFragment();
	for (var i = 0; i < emojis.length; i++){
		//tao blocl emoji
		var block_emoji = document.createElement("div");
		block_emoji.className = "blockEmoji";
		block_emoji.id = "blockEmoji" + i;
		array_id_runtime[i] = block_emoji.id ;
		
		block_emoji.innerHTML = String.fromCodePoint(emojis[i]);
		
		//if(i >= 5 && i%5 == 0){
		//	block_emoji.style.display = "inline-block";
		//}
		//block_emoji.background = t.array[key=i].src.icon;
		toAdd.appendChild(block_emoji);
		/*var img = document.createElement("image");
		img.className = "emoji";
		img.src = t.array[key=i].src.icon;
		block_emoji.appendChild("img");*/
	}
	document.getElementById("emoji_khung_trong-er").appendChild(toAdd);
}

function turn_on_of_block_emoji(){
	jQuery(document).ready(function() {
		$(document).on('click','body, #_id_button_emoji, #close_bt, .blockEmoji, #emoji_khung_trong, #emoji_khung_trong-er',function(ev){
			ev.stopPropagation();
			
			for(var i = 0; i < emojis.length; i++){
				if(ev.target.id == "blockEmoji"+i){
					$('#emoji_khung_trong').fadeIn();
					$('#tx').focus();
				}
			}
			
			if(ev.target.id == "_id_button_emoji" || ev.target.id == "close_bt"){
				if($('#emoji_khung_trong').is(':visible')) {
					  $('#emoji_khung_trong').fadeOut();
					  
				} else{
				  $('#emoji_khung_trong').fadeIn();
				  $('#tx').focus();
				}
			}
			else if(ev.target.className == ".blockEmoji" ){
				if($('#emoji_khung_trong').is(':visible')) {
					$('#emoji_khung_trong').fadeIn();
				} else{
					$('#emoji_khung_trong').fadeIn();
				}
				$('#tx').focus();
			}
			else if (ev.target.id == "emoji_khung_trong" || ev.target.id == "emoji_khung_trong-er" || ev.target.id == "tx"){
				if($('#emoji_khung_trong').is(':visible')) {
					$('#emoji_khung_trong').fadeIn();
				}
				$('#tx').focus();
			}
			
			else if (inArray(ev.target.id, array_id_runtime) === true){
				$('#emoji_khung_trong').fadeIn();
				$('#tx').focus();
			}
			
			else{
				$('#emoji_khung_trong').fadeOut();
			}
		});
	});
}

function inArray(target, array)
{
  for(var i = 0; i < array.length; i++) 
  {
    if(array[i] === target)
    {
      return true;
    }
  }

  return false; 
}




//SELECT * FROM cp.`*.json`
//$.array[?(@.key=2)].src.icon
/*{
        var ctl = document.getElementById('Javascript_example');
        var startPos = ctl.selectionStart;
        var endPos = ctl.selectionEnd;
      }*/
